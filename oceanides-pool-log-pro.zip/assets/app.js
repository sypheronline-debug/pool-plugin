
(function(){
  if (!window.OPL_DATA) return;
  const { settings, rest, i18n } = window.OPL_DATA;
  const mount = document.getElementById('opl-app');
  if (!mount) return;
  const T = i18n[settings.lang] || i18n.en;

  const escapeHtml = (s) => (s||'').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

  const headerHTML = /*html*/`
    <header class="flex flex-col items-center mb-4 text-center">
      <div class="opl-logo-wrap mb-2">${settings.logo_url ? `<img src="${settings.logo_url}" alt="Logo">` : ``}</div>
      <h1 class="text-2xl font-bold flex items-center gap-2"><i data-lucide="waves"></i> ${escapeHtml(settings.title)}</h1>
      ${settings.subtitle ? `<div class="text-sm text-gray-600 mt-1">${escapeHtml(settings.subtitle)}</div>` : ``}
    </header>
  `;

  const liveStatusHTML = /*html*/`
    <section class="mb-8">
      <h2 class="text-xl font-semibold flex items-center gap-2 mb-3"><i data-lucide="activity"></i> Live Status (Good • Moderate • Bad)</h2>
      <div class="space-y-4" id="statusBars">
        <div>
          <div class="flex items-center justify-between text-sm mb-1"><span class="font-medium">pH</span><span id="phLabel" class="text-gray-500">—</span></div>
          <div class="relative h-3 rounded-full overflow-hidden grad-symmetric-soft">
            <div id="phIndicator" class="absolute -top-1 h-5 w-1 bg-black/80 rounded"></div>
          </div>
          <div class="flex justify-between text-[11px] text-gray-500 mt-1"><span>6.5</span><span>7.1</span><span>7.3</span><span>7.5</span><span>8.0</span></div>
        </div>
        <div>
          <div class="flex items-center justify-between text-sm mb-1"><span class="font-medium">Free Chlorine (DPD1) mg/L</span><span id="fcLabel" class="text-gray-500">—</span></div>
          <div class="relative h-3 rounded-full overflow-hidden grad-symmetric-soft">
            <div id="fcIndicator" class="absolute -top-1 h-5 w-1 bg-black/80 rounded"></div>
          </div>
          <div class="flex justify-between text-[11px] text-gray-500 mt-1"><span>0</span><span>2</span><span>4.2</span><span>5</span><span>8</span></div>
        </div>
        <div>
          <div class="flex items-center justify-between text-sm mb-1"><span class="font-medium">Chloramines (CC)</span><span id="ccLabel" class="text-gray-500">—</span></div>
          <div class="relative h-3 rounded-full overflow-hidden grad-cc">
            <div id="ccIndicator" class="absolute -top-1 h-5 w-1 bg-black/80 rounded"></div>
          </div>
          <div class="flex justify-between text-[11px] text-gray-500 mt-1"><span>0</span><span>0.3</span><span>0.6</span><span>1.0</span><span>1.5</span></div>
        </div>
        <div>
          <div class="flex items-center justify-between text-sm mb-1"><span class="font-medium">CYA mg/L</span><span id="cyaLabel" class="text-gray-500">—</span></div>
          <div class="relative h-3 rounded-full overflow-hidden grad-cya">
            <div id="cyaIndicator" class="absolute -top-1 h-5 w-1 bg-black/80 rounded"></div>
          </div>
          <div class="flex justify-between text-[11px] text-gray-500 mt-1"><span>0</span><span>30</span><span>60</span><span>75</span><span>100</span></div>
        </div>
      </div>
    </section>
  `;

  const tasksHTML = /*html*/`
      <section class="mb-8">
        <h2 class="text-xl font-semibold flex items-center gap-2 mb-3">
          <i data-lucide="check-square"></i> ${T.daily}
        </h2>
        <div class="grid md:grid-cols-3 grid-cols-2 gap-2 text-sm">
          ${renderTaskCol(settings.tasks_daily, 'daily', T.daily)}
          ${renderTaskCol(settings.tasks_twice, 'twice', T.twice)}
          ${renderTaskCol(settings.tasks_weekly, 'weekly', T.weekly)}
        </div>
      </section>
  `;

  const formHTML = /*html*/`
      <section class="mb-8">
        <h2 class="text-xl font-semibold flex items-center gap-2 mb-3">
          <i data-lucide="flask-conical"></i> ${T.test_results}
        </h2>
        <form id="poolForm" class="grid md:grid-cols-4 grid-cols-2 gap-4">
          <label class="flex flex-col text-sm">Date <input id="date" type="date" class="border rounded p-2"/></label>
          <label class="flex flex-col text-sm">${T.session}
            <select id="time" class="border rounded p-2">
              <option value="07:30">07:30</option>
              <option value="16:00">16:00</option>
            </select>
          </label>
          <label class="flex flex-col text-sm">${T.sample_location} <input id="location" type="text" value="Between skimmers" class="border rounded p-2"/></label>
          <div></div>
          <label class="flex flex-col text-sm">${T.ph} <input id="ph" type="number" step="0.1" min="0" class="border rounded p-2"/></label>
          <label class="flex flex-col text-sm">${T.dpd1} <input id="dpd1" type="number" step="0.1" min="0" class="border rounded p-2"/></label>
          <label class="flex flex-col text-sm">${T.dpd3} <input id="dpd3" type="number" step="0.1" min="0" class="border rounded p-2"/></label>
          <label class="flex flex-col text-sm">${T.cc} <input id="cc" type="number" step="0.1" class="border rounded p-2 bg-gray-50" readonly/></label>
          <label class="flex flex-col text-sm">${T.water} <input id="waterTemp" type="number" step="0.1" class="border rounded p-2"/></label>
          <label class="flex flex-col text-sm">${T.air} <input id="airTemp" type="number" step="0.1" class="border rounded p-2"/></label>
          <label class="flex flex-col text-sm">${T.weather}
            <select id="weather" class="border rounded p-2">
              <option>☀️ Sunny</option>
              <option>🌤️ Cloudy</option>
              <option>🌧️ Rain</option>
              <option>🌬️ Windy</option>
              <option>⛅ Mixed</option>
            </select>
          </label>
          <label class="flex flex-col text-sm">${T.cya} <input id="cya" type="number" step="1" min="0" class="border rounded p-2" placeholder="Optional"/></label>
        </form>

        <div class="flex flex-wrap gap-3 mt-4">
          <button id="evaluateBtn" class="no-print inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl shadow">
            <i data-lucide="stethoscope"></i> ${T.evaluate}
          </button>
          <button id="vacuumGuideBtn" class="no-print inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl shadow">
            <i data-lucide="broom"></i> ${T.vacuum}
          </button>
          <button id="saveBtn" class="no-print inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl shadow">
            <i data-lucide="save"></i> ${T.save}
          </button>
          <button id="clearBtn" class="no-print inline-flex items-center gap-2 bg-gray-200 hover:bg-gray-300 text-gray-900 px-4 py-2 rounded-xl shadow">
            <i data-lucide="eraser"></i> ${T.clear}
          </button>
        </div>
        <p id="statusMsg" class="mt-3 text-sm"></p>
      </section>
  `;

  const recentHTML = /*html*/`
      <section>
        <h2 class="text-xl font-semibold flex items-center gap-2 mb-3">
          <i data-lucide="calendar"></i> Recent Server Logs
        </h2>
        <div class="overflow-x-auto">
          <table class="w-full border text-sm" id="historyTable">
            <thead class="bg-gray-100">
              <tr>
                <th class="border p-2">Date</th>
                <th class="border p-2">Time</th>
                <th class="border p-2">Residence</th>
                <th class="border p-2">pH</th>
                <th class="border p-2">DPD1</th>
                <th class="border p-2">DPD3</th>
                <th class="border p-2">CC</th>
                <th class="border p-2">CYA</th>
                <th class="border p-2">Water</th>
                <th class="border p-2">Air</th>
                <th class="border p-2">Weather</th>
                <th class="border p-2">Tasks</th>
                <th class="border p-2">Author</th>
                <th class="border p-2">Actions</th>
              </tr>
            </thead>
            <tbody id="historyBody"></tbody>
          </table>
        </div>
      </section>
  `;

  const pageHTML = /*html*/`
  <div class="bg-gray-100 p-6">
    <div class="max-w-5xl mx-auto bg-white shadow-lg rounded-2xl p-6">
      ${headerHTML}
      ${liveStatusHTML}
      ${tasksHTML}
      ${formHTML}
      ${recentHTML}
    </div>
  </div>

  <!-- Evaluate Modal -->
  <div id="alertModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center p-4">
    <div class="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl">
      <div class="flex items-center justify-between mb-3">
        <h3 class="text-lg font-semibold flex items-center gap-2"><i data-lucide="shield"></i> Compliance & Action Guidance</h3>
        <button id="closeModal" class="p-2 rounded-lg hover:bg-gray-100"><i data-lucide="x"></i></button>
      </div>
      <div id="modalContent" class="space-y-3 text-sm leading-6"></div>
      <div class="mt-4 flex items-center justify-end gap-3">
        <!-- Print button intentionally removed per request -->
        <button id="printClosureNotice" class="no-print hidden inline-flex items-center gap-2 bg-red-700 hover:bg-red-800 text-white px-3 py-2 rounded-xl shadow"><i data-lucide="megaphone"></i> ${T.print_public}</button>
        <button id="acknowledge" class="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-2 rounded-xl shadow"><i data-lucide="check"></i> OK</button>
      </div>
    </div>
  </div>

  <!-- Vacuum Guide Modal -->
  <div id="vacuumModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center p-4">
    <div class="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl">
      <div class="flex items-center justify-between mb-3">
        <h3 class="text-lg font-semibold flex items-center gap-2"><i data-lucide="hand"></i> Manual Vacuum – Skimmer Hose Method</h3>
        <button id="closeVacuum" class="p-2 rounded-lg hover:bg-gray-100"><i data-lucide="x"></i></button>
      </div>
      <div class="space-y-3 text-sm leading-6">
        <ol class="list-decimal pl-5">
          <li>At the filter room: <b>close valves 2, 4, 5</b> and <b>leave valve 3 open</b>.</li>
          <li>Poolside: attach the vacuum <b>head</b> to the <b>pole</b> and connect the <b>hose</b>.</li>
          <li>Prime the hose: lower the head to the floor, then feed the hose into the water <b>slowly</b> to purge all air <em>until fully water-filled</em>.</li>
          <li>Attach the hose to <b>skimmer #3</b>. Begin vacuuming the floor in <b>overlapping lines</b> at a slow pace.</li>
        </ol>
        <p class="text-red-700 font-semibold">IMPORTANT: When finished, <u>restore normal flow</u> — set skimmer valves <b>2, 4, 5 back to their standard positions</b> (with valve 3 as per normal). Verify circulation before leaving.</p>
      </div>
      <div class="mt-4 flex items-center justify-end gap-3">
        <button id="printVacuum" class="no-print inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-900 text-white px-3 py-2 rounded-xl shadow"><i data-lucide="printer"></i> ${T.print}</button>
        <button id="ackVacuum" class="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-2 rounded-xl shadow"><i data-lucide="check"></i> OK</button>
      </div>
    </div>
  </div>
  `;

  function renderTaskCol(list, key, title){
    const rows = (list||[]).map((t,i)=>`<label class="flex items-center gap-2"><input id="chk_${key}_${i}" type="checkbox"/> ${escapeHtml(t)}</label>`).join('');
    return `<div class="space-y-2"><p class="text-xs font-semibold text-gray-600">${escapeHtml(title)}</p>${rows||'<p class="text-xs text-gray-500">—</p>'}</div>`;
  }

  mount.innerHTML = pageHTML;
  if (window.lucide && window.lucide.createIcons) window.lucide.createIcons();

  // Constants
  const ARS = { PH_MIN: 6.9, PH_MAX: 7.7, FC_MIN: 2.0, FC_MAX: 5.0, CC_MAX: 0.6, CYA_MAX: 75, TARGET_FC: 4.2 };

  // Helpers
  const $ = id => document.getElementById(id);
  const clamp = (n,min,max) => Math.min(Math.max(n,min),max);
  const pct = (val,min,max) => ((clamp(val,min,max)-min)/(max-min))*100;
  function classifyPh(v){ if(isNaN(v)) return '—'; if(v<ARS.PH_MIN||v>ARS.PH_MAX) return 'Bad'; if(Math.abs(v-7.3)<=0.2) return 'Good'; return 'Moderate'; }
  function classifyFC(v){ if(isNaN(v)) return '—'; if(v<ARS.FC_MIN||v>ARS.FC_MAX) return 'Bad'; if(v>=3.6&&v<=4.6) return 'Good'; return 'Moderate'; }
  function classifyCC(v){ if(isNaN(v)) return '—'; if(v>0.7) return 'Bad'; if(v>0.5) return 'Moderate'; return 'Good'; }
  function classifyCYA(v){ if(isNaN(v)) return '—'; if(v>ARS.CYA_MAX) return 'Bad'; if(v>=30 && v<=60) return 'Good'; return 'Moderate'; }

  function updateGauges(){
    const ph = parseFloat($("ph").value);
    const fc = parseFloat($("dpd1").value);
    const cc = parseFloat($("cc").value);
    const cya = parseFloat($("cya").value);
    const set = (id, v, min, max) => { const el = document.getElementById(id); if (el) el.style.left = (isNaN(v)? 0 : pct(v,min,max)) + "%"; };
    set("phIndicator", ph||7.3, 6.5, 8.0);
    set("fcIndicator", fc||4.2, 0, 8);
    set("ccIndicator", cc||0, 0, 1.5);
    set("cyaIndicator", cya||0, 0, 100);
    const label = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text; };
    label("phLabel", isNaN(ph)?'—':`${ph.toFixed(2)} (${classifyPh(ph)})`);
    label("fcLabel", isNaN(fc)?'—':`${fc.toFixed(2)} (${classifyFC(fc)})`);
    label("ccLabel", isNaN(cc)?'—':`${cc.toFixed(2)} (${classifyCC(cc)})`);
    label("cyaLabel", isNaN(cya)?'—':`${cya.toFixed(0)} (${classifyCYA(cya)})`);
  }

  function computeCC(){
    const d1 = parseFloat($("dpd1").value), d3 = parseFloat($("dpd3").value);
    $("cc").value = (!isNaN(d1)&&!isNaN(d3)) ? Math.max(0, +(d3-d1).toFixed(2)) : "";
    updateGauges();
  }
  ["ph","dpd1","dpd3","cya"].forEach(id=> $(id).addEventListener('input', updateGauges));
  ["dpd1","dpd3"].forEach(id=> $(id).addEventListener('input', computeCC));

  function setDefaults(){
    const now = new Date();
    $("date").value = now.toISOString().slice(0,10);
    $("time").value = (now.getHours() < 12 ? "07:30" : "16:00");
  }
  setDefaults(); updateGauges();

  function msg(text, warn){
    const el = $("statusMsg"); el.textContent = text; el.className = `mt-3 text-sm ${warn? 'text-red-700':'text-emerald-700'}`;
  }

  // Evaluate & modal
  function evaluate(){
    const ph = parseFloat($("ph").value);
    const fc = parseFloat($("dpd1").value);
    const cc = parseFloat($("cc").value);
    const cya = parseFloat($("cya").value);
    let mustClose = false; const breaches = [];

    if(!isNaN(ph) && (ph < ARS.PH_MIN || ph > ARS.PH_MAX)){{ mustClose = true; breaches.push(`pH out of legal range (${ph})`); }}
    if(!isNaN(fc) && (fc < ARS.FC_MIN || fc > ARS.FC_MAX)){{ mustClose = true; breaches.push(fc < ARS.FC_MIN ? `Free chlorine too low (${fc} mg/L)` : `Free chlorine too high (${fc} mg/L)`); }}
    if(!isNaN(cc) && cc > ARS.CC_MAX){{ mustClose = true; breaches.push(`Combined chlorine (chloramines) too high (${cc} mg/L)`); }}
    if(!isNaN(cya) && cya > ARS.CYA_MAX){{ mustClose = true; breaches.push(`CYA too high (${cya} mg/L)`); }}

    const header = mustClose
      ? `<div class="flex items-center gap-2 text-red-700"><i data-lucide="octagon"></i><b>${T.closed}</b></div>`
      : `<div class="flex items-center gap-2 text-emerald-700"><i data-lucide="shield-check"></i><b>${T.compliant}</b></div>`;

    document.getElementById("modalContent").innerHTML = header + (breaches.length ? `<ul class="list-disc pl-5 mt-2">${breaches.map(b=>`<li>${escapeHtml(b)}</li>`).join('')}</ul>` : '');
    document.getElementById("alertModal").classList.remove("hidden");
    if (window.lucide) window.lucide.createIcons();

    window.__closureData = {
      mustClose: mustClose,
      breaches,
      date: $("date").value, session: $("time").value, location: $("location").value,
      readings: { ph, fc, cc, cya }
    };
    document.getElementById('printClosureNotice').classList.toggle('hidden', !mustClose);
  }

  // Professional A4 Public Closure Notice
  function buildClosureNoticeHTML(data){
    const fmt = (v, digits=2) => (isNaN(v) ? '—' : Number(v).toFixed(digits));
    const today = new Date();
    const dateLine = data.date || today.toISOString().slice(0,10);
    const timeLine = data.session || `${today.getHours().toString().padStart(2,'0')}:${today.getMinutes().toString().padStart(2,'0')}`;
    const loc = data.location || 'Pool deck';
    const reasons = (data.breaches || []).map(r=>`<li>${escapeHtml(r)}</li>`).join('');
    return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>POOL CLOSED – Public Notice</title>
      <style>
        @page {{ size: A4; margin: 14mm; }}
        body {{ font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; color:#0f172a; }}
        .res {{ font-size: 34px; font-weight: 800; text-align:center; letter-spacing:.02em; margin-bottom: 12px; }}
        .card {{ border: 4px solid #b91c1c; border-radius: 14px; padding: 18px; }}
        .title {{ display:flex; flex-direction:column; align-items:center; gap:10px; margin-bottom: 6px; }}
        .icon {{ margin-top:2px; }}
        .closed {{ font-size: 36px; font-weight: 900; color:#b91c1c; letter-spacing:.05em; }}
        .meta {{ font-size: 15px; text-align:center; margin: 8px 0 6px 0; }}
        h2 {{ font-size: 20px; margin: 10px 0 6px 0; }}
        ul {{ margin: 4px 0 0 20px; font-size: 16px; }}
        .readings {{ margin-top: 8px; font-size: 15px; }}
        .law {{ margin-top: 10px; font-size: 13px; color:#334155; }}
      </style></head><body>
      <div class="res">${escapeHtml(settings.residence)}</div>
      <div class="card">
        <div class="title">
          <div class="icon"><svg width="84" height="84" viewBox="0 0 24 24" fill="none" stroke="#b91c1c" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg></div>
          <div class="closed">POOL CLOSED</div>
        </div>
        <div class="meta">Date: ${dateLine} • Time: ${timeLine} • Sample: ${escapeHtml(loc)}</div>
        <h2>Reason(s) – ARS compliance</h2>
        <ul>${reasons}</ul>
        <div class="readings"><b>Readings:</b> pH ${fmt(data.readings.ph)} | Free Chlorine (DPD1) ${fmt(data.readings.fc)} mg/L | Combined Chlorine (CC) ${fmt(data.readings.cc)} mg/L | CYA ${fmt(data.readings.cya,0)} mg/L</div>
        <div class="law"><b>ARS limits</b>: pH 6.9–7.7 • Free chlorine 2–5 mg/L • Combined chlorine ≤ 0.6 mg/L • CYA ≤ 75 mg/L. The pool reopens when all values return within limits.</div>
      </div>
    </body></html>`;
  }

  function printClosureNotice(){
    const data = window.__closureData || {mustClose:false};
    if(!data.mustClose){ alert('Compliant; no closure notice to print.'); return; }
    const w = window.open('', '_blank'); w.document.open(); w.document.write(buildClosureNoticeHTML(data)); w.document.close(); w.focus(); w.print();
  }

  // Save
  async function saveEntry(){
    const payload = {
      date: $("date").value, time: $("time").value,
      location: $("location").value, ph: $("ph").value, dpd1: $("dpd1").value, dpd3: $("dpd3").value,
      cc: $("cc").value, cya: $("cya").value, waterTemp: $("waterTemp").value, airTemp: $("airTemp").value,
      weather: $("weather").value, tasks: gatherTasks()
    };
    if(!payload.date || !payload.time){ msg('Please set date and time.', true); return; }
    try{
      const res = await fetch(rest.root + 'save', { method:'POST', headers:{ 'Content-Type':'application/json', 'X-WP-Nonce': rest.nonce }, body: JSON.stringify(payload)});
      const j = await res.json();
      if(!j.ok) throw new Error(j.error||'Save failed');
      msg('Saved to server.');
      listLogs();
    }catch(e){ console.error(e); msg('Save error: '+e.message, true); }
  }

  function gatherTasks(){
    const all = [];
    document.querySelectorAll('input[id^="chk_"]').forEach(cb => { if (cb.checked) all.push(cb.parentElement.textContent.trim()); });
    return all;
  }

  async function listLogs(){
    try{
      const res = await fetch(rest.root + 'list', { headers: { 'X-WP-Nonce': rest.nonce } });
      const j = await res.json();
      if(!j.ok) throw new Error('List failed');
      const rows = j.items.map(e => `
        <tr>
          <td class="border p-2">${e.date||''}</td>
          <td class="border p-2">${e.time||''}</td>
          <td class="border p-2">${escapeHtml(e.site||'')}</td>
          <td class="border p-2">${e.ph||''}</td>
          <td class="border p-2">${e.dpd1||''}</td>
          <td class="border p-2">${e.dpd3||''}</td>
          <td class="border p-2">${e.cc||''}</td>
          <td class="border p-2">${e.cya||''}</td>
          <td class="border p-2">${e.waterTemp||''}</td>
          <td class="border p-2">${e.airTemp||''}</td>
          <td class="border p-2">${escapeHtml(e.weather||'')}</td>
          <td class="border p-2">${escapeHtml(e.tasks||'')}</td>
          <td class="border p-2">${escapeHtml(e.author||'')}</td>
          <td class="border p-2"><button class="text-red-700 hover:underline" data-del="${e.id}">Delete</button></td>
        </tr>`).join('');
      document.getElementById('historyBody').innerHTML = rows;
    }catch(e){ console.error(e); msg('Load error: '+e.message, true); }
  }

  // events
  document.getElementById('evaluateBtn').addEventListener('click', evaluate);
  document.getElementById('printClosureNotice').addEventListener('click', printClosureNotice);
  document.getElementById('closeModal').addEventListener('click', ()=>document.getElementById('alertModal').classList.add('hidden'));
  document.getElementById('acknowledge').addEventListener('click', ()=>document.getElementById('alertModal').classList.add('hidden'));
  document.getElementById('saveBtn').addEventListener('click', saveEntry);
  document.getElementById('clearBtn').addEventListener('click', ()=>{ document.getElementById('poolForm').reset(); setDefaults(); updateGauges(); });
  document.getElementById('vacuumGuideBtn').addEventListener('click', ()=> document.getElementById('vacuumModal').classList.remove('hidden'));
  document.getElementById('closeVacuum').addEventListener('click', ()=> document.getElementById('vacuumModal').classList.add('hidden'));
  document.getElementById('ackVacuum').addEventListener('click', ()=> document.getElementById('vacuumModal').classList.add('hidden'));
  document.getElementById('printVacuum').addEventListener('click', ()=>{
    const modalContent = document.querySelector('#vacuumModal .bg-white');
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>Vacuum Guide</title>
      <style>@page{{margin:12mm}} body{{font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; margin:24px;}}</style>
      </head><body>${modalContent.innerHTML}</body></html>`;
    const w = window.open('', '_blank'); w.document.open(); w.document.write(html); w.document.close(); w.focus(); w.print();
  });

  document.getElementById('historyTable').addEventListener('click', async (ev)=>{
    const id = ev.target.closest('[data-del]')?.getAttribute('data-del');
    if (!id) return;
    if (!confirm('Delete this log?')) return;
    try{
      const res = await fetch(rest.root + 'delete/'+id, { method:'DELETE', headers:{ 'X-WP-Nonce': rest.nonce } });
      const j = await res.json();
      if(!j.ok) throw new Error('Delete failed');
      listLogs();
    }catch(e){ msg('Delete error: '+e.message, true); }
  });

  // init
  if (window.lucide && window.lucide.createIcons) window.lucide.createIcons();
  listLogs();
})();
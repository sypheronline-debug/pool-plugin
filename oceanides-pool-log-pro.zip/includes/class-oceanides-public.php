<?php

class Oceanides_Public {

    public function __construct() {
        add_shortcode('oceanides_pool_log', array($this, 'render_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function render_shortcode() {
        return '<div id="oceanides-app"></div>';
    }

    public function enqueue_scripts() {
        global $post;
        if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'oceanides_pool_log' ) ) {
            $app_js_path = OPLP_PLUGIN_DIR . 'assets/app.js';
            if ( file_exists( $app_js_path ) ) {
                wp_enqueue_script(
                    'oceanides-app-js',
                    plugin_dir_url( __FILE__ ) . '../assets/app.js',
                    ['wp-element', 'wp-api-fetch'], filemtime($app_js_path), true
                );
            }
            // Pass translated strings and data to JavaScript
            wp_localize_script('oceanides-app-js', 'oceanides_data', [
                'rest_url' => esc_url_raw( rest_url( 'oceanides/v1/logs' ) ),
                'nonce'    => wp_create_nonce( 'wp_rest' ),
                'i18n'     => [
                    'mainTitle'         => __('Pool Water Quality Records', 'oceanides-pool-log-pro'),
                    'newReadingTitle'   => __('Enter New Water Readings', 'oceanides-pool-log-pro'),
                    'savedRecordsTitle' => __('Saved Records', 'oceanides-pool-log-pro'),
                    'dateLabel'         => __('Date', 'oceanides-pool-log-pro'),
                    'phLabel'           => __('pH Level', 'oceanides-pool-log-pro'),
                    'chlorineLabel'     => __('Chlorine Level (ppm)', 'oceanides-pool-log-pro'),
                    'alkalinityLabel'   => __('Total Alkalinity (ppm)', 'oceanides-pool-log-pro'),
                    'hardnessLabel'     => __('Calcium Hardness (ppm)', 'oceanides-pool-log-pro'),
                    'notesLabel'        => __('Notes', 'oceanides-pool-log-pro'),
                    'notesPlaceholder'  => __('Any observations...', 'oceanides-pool-log-pro'),
                    'saveButton'        => __('Save Record', 'oceanides-pool-log-pro'),
                    'noRecords'         => __('No records found.', 'oceanides-pool-log-pro'),
                ]
            ]);
        }
    }
}
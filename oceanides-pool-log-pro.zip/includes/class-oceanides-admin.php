<?php

class Oceanides_Admin {

    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public static function install() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'oceanides_pool_logs';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            reading_date date NOT NULL, ph_level decimal(4,2) NOT NULL,
            chlorine_level decimal(4,2) NOT NULL, alkalinity int(11) NOT NULL,
            calcium_hardness int(11) DEFAULT 0 NOT NULL, notes text,
            created_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
    }

    public function admin_menu() {
        add_menu_page(
            __('Oceanides Pool Log', 'oceanides-pool-log-pro'), 'Oceanides',
            'manage_options', 'oceanides-pool-log-pro',
            array($this, 'admin_page'), 'dashicons-chart-area', 20
        );
    }

    public function admin_page() {
        echo '<div class="wrap"><div id="oceanides-app"></div></div>';
    }

    public function enqueue_scripts($hook) {
        if ('toplevel_page_oceanides-pool-log-pro' != $hook) return;
        $app_js_path = OPLP_PLUGIN_DIR . 'assets/app.js';
        if ( file_exists( $app_js_path ) ) {
            wp_enqueue_script('oceanides-app-js', plugin_dir_url( __FILE__ ) . '../assets/app.js',
                ['wp-element', 'wp-api-fetch'], filemtime($app_js_path), true
            );
        }
        // Pass data to JavaScript
        wp_localize_script('oceanides-app-js', 'oceanides_data', [
            'rest_url' => esc_url_raw( rest_url( 'oceanides/v1/logs' ) ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
            'i18n'     => [
                'mainTitle' => __('Pool Water Quality Records', 'oceanides-pool-log-pro'),
                // Add all other translations here
            ]
        ]);
    }
}
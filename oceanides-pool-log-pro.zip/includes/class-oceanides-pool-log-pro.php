<?php

class Oceanides_Pool_Log_Pro {

    /**
     * Constructor. Loads all necessary files and hooks into WordPress.
     */
    public function __construct() {
        $this->includes();
        
        // Use the 'init' hook to safely instantiate our classes
        add_action('init', array($this, 'init_classes'));
    }

    /**
     * Includes all the required files for the plugin.
     */
    private function includes() {
        // We don't need to include the admin class here anymore, 
        // as the main plugin file does it for the activation hook.
        require_once OPLP_PLUGIN_DIR . 'includes/class-oceanides-public.php';
        require_once OPLP_PLUGIN_DIR . 'includes/class-oceanides-rest.php';
    }

    /**
     * Instantiates the classes that add the hooks.
     * This function is called at the right time by the 'init' action.
     */
    public function init_classes() {
        new Oceanides_Admin();
        new Oceanides_Public();
        new Oceanides_Rest();
    }
}
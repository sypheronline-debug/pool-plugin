<?php
/**
 * Plugin Name: Oceanides Pool Log Pro
 * Version: 2.2.0
 * Author: Your Name
 * Text Domain: oceanides-pool-log-pro
 * Domain Path: /languages
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

define( 'OPLP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Include the two classes needed before WordPress hooks run
require_once OPLP_PLUGIN_DIR . 'includes/class-oceanides-admin.php';
require_once OPLP_PLUGIN_DIR . 'includes/class-oceanides-pool-log-pro.php';

// Register the activation hook
register_activation_hook( __FILE__, [ 'Oceanides_Admin', 'install' ] );

// Load the text domain for translations
add_action( 'plugins_loaded', function() {
    load_plugin_textdomain( 'oceanides-pool-log-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
});

// Instantiate the main class to get everything started.
new Oceanides_Pool_Log_Pro();
<?php
/**
 * Plugin Name: Oceanides Pool Log Pro
 * Description: Server-saved daily pool log with ARS evaluator, printable closure notices, tasks editor, branding, EN/FR, CSV export (admin). Shortcode: [oceanides_pool_log]
 * Version: 2.4.0
 * Author: Le Rosebif
 * License: GPL-2.0-or-later
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

class OPL_Pro_V24 {
  const CPT = 'opl_log';
  const OPT = 'opl_settings_v24';

  public function __construct(){
    add_action('init', [$this, 'register_types']);
    add_action('admin_menu', [$this, 'admin_menu'], 20);
    add_action('admin_init', [$this, 'register_settings']);
    add_action('wp_enqueue_scripts', [$this, 'register_assets']);
    add_shortcode('oceanides_pool_log', [$this, 'shortcode']);
    add_action('rest_api_init', [$this, 'register_rest']);
  }

  public function register_types(){
    register_post_type(self::CPT, [
      'label' => 'Pool Logs',
      'public' => false,
      'show_ui' => true,
      'supports' => ['title', 'author'],
      'capability_type' => 'post',
      'map_meta_cap' => true,
      'capabilities' => [ 'create_posts' => 'do_not_allow' ], // hide Add New
      'menu_icon' => 'dashicons-clipboard',
    ]);
  }

  public function admin_menu(){
    // Remove "Add New" submenu for CPT
    remove_submenu_page('edit.php?post_type='.self::CPT, 'post-new.php?post_type='.self::CPT);

    add_submenu_page('edit.php?post_type='.self::CPT, 'Settings', 'Settings', 'manage_options', 'opl-settings', [$this,'settings_page']);
    add_submenu_page('edit.php?post_type='.self::CPT, 'Export CSV', 'Export CSV', 'manage_options', 'opl-export', [$this,'export_page']);
  }

  public function register_settings(){
    register_setting(self::OPT, self::OPT, [
      'type' => 'array',
      'default' => [
        'residence_name' => 'Résidence Les Océanides',
        'subtitle' => 'ARS limits: pH 6.9–7.7 • FC 2–5 mg/L • CC ≤0.6 mg/L • CYA ≤75 mg/L',
        'logo_url' => '',
        'tasks_daily' => "Open gates & doors\nUnplug & clean foot washer\nRemove pool tarp\nVacuum pool floor via skimmer hose (manual)\nEmpty & clean skimmers\nCalibrate/prime dosing system\nCheck chlorine barrels (kids & large pool)\nInspect filter room (leaks/issues)\nFill pool if needed (stop pump first)\nLog in health book",
        'tasks_twice' => "Clean filter & refill",
        'tasks_weekly' => "Clean water line\nTest CYA & record bather load\nBrush walls/steps & inspect fittings",
        'lang' => 'en',
      ],
      'sanitize_callback' => function($opts){
        foreach (['residence_name','subtitle','logo_url','tasks_daily','tasks_twice','tasks_weekly','lang'] as $k){
          if(!isset($opts[$k])) $opts[$k] = '';
          $opts[$k] = is_string($opts[$k]) ? wp_kses_post($opts[$k]) : $opts[$k];
        }
        $opts['lang'] = in_array($opts['lang'], ['en','fr']) ? $opts['lang'] : 'en';
        return $opts;
      }
    ]);
  }

  public function settings_page(){
    if (!current_user_can('manage_options')) return;
    $o = get_option(self::OPT);
    ?>
    <div class="wrap">
      <h1>Oceanides Pool Log – Settings</h1>
      <form method="post" action="options.php">
        <?php settings_fields(self::OPT); ?>
        <table class="form-table" role="presentation">
          <tr><th scope="row"><label>Header (fixed)</label></th>
            <td><code>Daily Pool Log – [Residence Name]</code><p class="description">Edit only the residence name below.</p></td></tr>
          <tr><th scope="row"><label>Residence Name</label></th>
            <td><input type="text" name="<?php echo self::OPT; ?>[residence_name]" value="<?php echo esc_attr($o['residence_name']); ?>" class="regular-text" /></td></tr>
          <tr><th scope="row"><label>Subtitle</label></th>
            <td><input type="text" name="<?php echo self::OPT; ?>[subtitle]" value="<?php echo esc_attr($o['subtitle']); ?>" class="regular-text" /></td></tr>
          <tr><th scope="row"><label>Logo URL</label></th>
            <td><input type="url" name="<?php echo self::OPT; ?>[logo_url]" value="<?php echo esc_attr($o['logo_url']); ?>" class="regular-text" />
              <p class="description">Rendered auto-sized (max-width 300px, height auto).</p></td></tr>
          <tr><th scope="row"><label>Language</label></th>
            <td>
              <select name="<?php echo self::OPT; ?>[lang]">
                <option value="en" <?php selected($o['lang'],'en'); ?>>English</option>
                <option value="fr" <?php selected($o['lang'],'fr'); ?>>Français</option>
              </select>
            </td></tr>
          <tr><th scope="row"><label>Daily Tasks</label></th>
            <td><textarea name="<?php echo self::OPT; ?>[tasks_daily]" rows="8" cols="60"><?php echo esc_textarea($o['tasks_daily']); ?></textarea></td></tr>
          <tr><th scope="row"><label>Twice Weekly Tasks</label></th>
            <td><textarea name="<?php echo self::OPT; ?>[tasks_twice]" rows="4" cols="60"><?php echo esc_textarea($o['tasks_twice']); ?></textarea></td></tr>
          <tr><th scope="row"><label>Weekly Tasks</label></th>
            <td><textarea name="<?php echo self::OPT; ?>[tasks_weekly]" rows="6" cols="60"><?php echo esc_textarea($o['tasks_weekly']); ?></textarea></td></tr>
        </table>
        <?php submit_button(); ?>
      </form>
    </div>
    <?php
  }

  public function export_page(){
    if (!current_user_can('manage_options')) return;
    if (isset($_GET['download']) && $_GET['download']==='csv'){
      $this->download_csv();
      return;
    }
    $url = admin_url('edit.php?post_type='.self::CPT.'&page=opl-export&download=csv&_wpnonce='.wp_create_nonce('opl_csv'));
    echo '<div class="wrap"><h1>Export CSV</h1><p><a class="button button-primary" href="'.esc_url($url).'">Download CSV</a></p></div>';
  }

  private function download_csv(){
    if (!wp_verify_nonce($_GET['_wpnonce'] ?? '', 'opl_csv')) wp_die('Invalid nonce');
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="oceanides_pool_logs.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['date','time','residence','location','ph','dpd1','dpd3','cc','cya','waterTemp','airTemp','weather','tasks','author','created']);
    $q = new WP_Query([ 'post_type' => self::CPT, 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'DESC' ]);
    $o = get_option(self::OPT);
    $res_name = $o['residence_name'] ?? '';
    foreach ($q->posts as $p){
      $meta = get_post_meta($p->ID);
      fputcsv($out, [
        $meta['opl_date'][0] ?? '',
        $meta['opl_time'][0] ?? '',
        $res_name,
        $meta['opl_location'][0] ?? '',
        $meta['opl_ph'][0] ?? '',
        $meta['opl_dpd1'][0] ?? '',
        $meta['opl_dpd3'][0] ?? '',
        $meta['opl_cc'][0] ?? '',
        $meta['opl_cya'][0] ?? '',
        $meta['opl_waterTemp'][0] ?? '',
        $meta['opl_airTemp'][0] ?? '',
        $meta['opl_weather'][0] ?? '',
        $meta['opl_tasks'][0] ?? '',
        get_the_author_meta('display_name', $p->post_author),
        $p->post_date
      ]);
    }
    fclose($out);
    exit;
  }

  public function register_assets(){
    wp_register_script('opl-lucide', 'https://unpkg.com/lucide@latest', [], null, true);
    wp_register_script('opl-tailwind', 'https://cdn.tailwindcss.com', [], null, true);
    wp_register_style('opl-css', plugins_url('assets/app.css', __FILE__), [], '2.4.0');
    wp_register_script('opl-js', plugins_url('assets/app.js', __FILE__), ['opl-lucide','opl-tailwind'], '2.4.0', true);
  }

  public function shortcode($atts){
    wp_enqueue_style('opl-css');
    wp_enqueue_script('opl-js');

    $o = get_option(self::OPT);
    $title = 'Daily Pool Log – ' . ($o['residence_name'] ?? '');

    $data = [
      'settings' => [
        'title' => $title,
        'residence' => $o['residence_name'] ?? '',
        'subtitle' => $o['subtitle'] ?? '',
        'logo_url' => $o['logo_url'] ?? '',
        'tasks_daily' => array_values(array_filter(array_map('trim', explode("\n", $o['tasks_daily'] ?? '')))),
        'tasks_twice' => array_values(array_filter(array_map('trim', explode("\n", $o['tasks_twice'] ?? '')))),
        'tasks_weekly' => array_values(array_filter(array_map('trim', explode("\n", $o['tasks_weekly'] ?? '')))),
        'lang' => $o['lang'] ?? 'en',
      ],
      'rest' => [
        'root' => esc_url_raw(rest_url('opl/v1/')),
        'nonce' => wp_create_nonce('wp_rest')
      ],
      'i18n' => [
        'en' => [
          'daily' => 'Daily Tasks',
          'twice' => 'Twice Weekly',
          'weekly' => 'Weekly',
          'test_results' => 'Test Results',
          'session' => 'Session (select time)',
          'sample_location' => 'Sample location',
          'ph' => 'pH (6.9–7.7)',
          'dpd1' => 'Free Chlorine DPD1 (2–5 mg/L)',
          'dpd3' => 'Total Chlorine DPD3',
          'cc' => 'Chloramines (auto) ≤0.6 mg/L',
          'water' => 'Pool water temp (°C)',
          'air' => 'Outdoor temp (°C)',
          'weather' => 'Weather',
          'cya' => 'CYA (stabilizer) mg/L (weekly)',
          'evaluate' => 'Evaluate & Guide',
          'save' => 'Save entry',
          'clear' => 'Clear',
          'vacuum' => 'Vacuum Guide',
          'closed' => 'POOL MUST BE CLOSED',
          'compliant' => 'Compliant – appears within ARS limits.',
          'print_public' => 'Print Public CLOSURE Notice',
          'print' => 'Print'
        ],
        'fr' => [
          'daily' => 'Tâches quotidiennes',
          'twice' => 'Deux fois par semaine',
          'weekly' => 'Hebdomadaire',
          'test_results' => 'Résultats d’analyse',
          'session' => 'Séance (choisir l’heure)',
          'sample_location' => 'Lieu de prélèvement',
          'ph' => 'pH (6,9–7,7)',
          'dpd1' => 'Chlore libre DPD1 (2–5 mg/L)',
          'dpd3' => 'Chlore total DPD3',
          'cc' => 'Chloramines (auto) ≤0,6 mg/L',
          'water' => 'Température eau (°C)',
          'air' => 'Température extérieure (°C)',
          'weather' => 'Météo',
          'cya' => 'CYA (stabilisant) mg/L (hebdo)',
          'evaluate' => 'Évaluer & Conseiller',
          'save' => 'Enregistrer',
          'clear' => 'Effacer',
          'vacuum' => 'Guide d’aspiration',
          'closed' => 'FERMETURE OBLIGATOIRE DU BASSIN',
          'compliant' => 'Conforme – semble dans les limites ARS.',
          'print_public' => 'Imprimer l’avis de FERMETURE',
          'print' => 'Imprimer'
        ]
      ]
    ];
    wp_localize_script('opl-js', 'OPL_DATA', $data);

    return '<div class="opl-wrapper"><div id="opl-app"></div></div>';
  }

  public function register_rest(){
    register_rest_route('opl/v1', '/save', [
      'methods' => 'POST',
      'permission_callback' => function(){ return is_user_logged_in() && current_user_can('edit_posts'); },
      'callback' => [$this, 'rest_save']
    ]);
    register_rest_route('opl/v1', '/list', [
      'methods' => 'GET',
      'permission_callback' => function(){ return is_user_logged_in(); },
      'callback' => [$this, 'rest_list']
    ]);
    register_rest_route('opl/v1', '/delete/(?P<id>\d+)', [
      'methods' => 'DELETE',
      'permission_callback' => function($req){ 
        $id = intval($req['id']); 
        return is_user_logged_in() && ( current_user_can('delete_post', $id) );
      },
      'callback' => [$this, 'rest_delete']
    ]);
  }

  public function rest_save($req){
    $p = $req->get_json_params();
    $title = sanitize_text_field(($p['date'] ?? '') . ' ' . ($p['time'] ?? ''));
    $post_id = wp_insert_post([
      'post_type' => self::CPT,
      'post_status' => 'publish',
      'post_title' => $title,
      'post_author' => get_current_user_id()
    ], true);
    if (is_wp_error($post_id)) return new WP_REST_Response(['ok'=>false,'error'=>$post_id->get_error_message()], 500);

    foreach (['date','time','location','ph','dpd1','dpd3','cc','cya','waterTemp','airTemp','weather','tasks'] as $f){
      if (isset($p[$f])) update_post_meta($post_id, 'opl_'.$f, wp_kses_post(is_array($p[$f])?implode(' | ', $p[$f]):$p[$f]));
    }
    return ['ok'=>true,'id'=>$post_id];
  }

  public function rest_list($req){
    $q = new WP_Query([
      'post_type' => self::CPT,
      'posts_per_page' => 50,
      'orderby' => 'date',
      'order' => 'DESC'
    ]);
    $o = get_option(self::OPT);
    $res_name = $o['residence_name'] ?? '';
    $out = [];
    foreach ($q->posts as $p){
      $meta = get_post_meta($p->ID);
      $out[] = [
        'id' => $p->ID,
        'date' => $meta['opl_date'][0] ?? '',
        'time' => $meta['opl_time'][0] ?? '',
        'site' => $res_name,
        'location' => $meta['opl_location'][0] ?? '',
        'ph' => $meta['opl_ph'][0] ?? '',
        'dpd1' => $meta['opl_dpd1'][0] ?? '',
        'dpd3' => $meta['opl_dpd3'][0] ?? '',
        'cc' => $meta['opl_cc'][0] ?? '',
        'cya' => $meta['opl_cya'][0] ?? '',
        'waterTemp' => $meta['opl_waterTemp'][0] ?? '',
        'airTemp' => $meta['opl_airTemp'][0] ?? '',
        'weather' => $meta['opl_weather'][0] ?? '',
        'tasks' => $meta['opl_tasks'][0] ?? '',
        'author' => get_the_author_meta('display_name', $p->post_author),
        'created' => $p->post_date
      ];
    }
    return ['ok'=>true,'items'=>$out];
  }

  public function rest_delete($req){
    $id = intval($req['id']);
    $res = wp_trash_post($id);
    if (!$res) return new WP_REST_Response(['ok'=>false], 400);
    return ['ok'=>true];
  }
}

new OPL_Pro_V24();

<?php
if (!defined('ABSPATH')) exit;

class Oceanides_Pool_REST {
  public function __construct(){
    add_action('rest_api_init', array($this,'routes'));
  }

  public function routes(){
    register_rest_route('oceanides/v1','/logs', array(
      array('methods'=>'GET','callback'=>array($this,'get_logs'),'permission_callback'=>array($this,'can_read')),
      array('methods'=>'POST','callback'=>array($this,'create_log'),'permission_callback'=>array($this,'can_write')),
    ));
    register_rest_route('oceanides/v1','/logs/(?P<id>\d+)', array(
      array('methods'=>'DELETE','callback'=>array($this,'delete_log'),'permission_callback'=>array($this,'can_write')),
    ));
    register_rest_route('oceanides/v1','/logs/export', array(
      array('methods'=>'GET','callback'=>array($this,'export_csv'),'permission_callback'=>array($this,'can_read')),
    ));
  }

  public function can_read($req){
    return is_user_logged_in();
  }
  public function can_write($req){
    return is_user_logged_in() && current_user_can('edit_posts') && wp_verify_nonce($req->get_header('X-WP-Nonce'), 'wp_rest');
  }

  public function create_log($req){
    $data = $req->get_json_params();
    if (!$data) return new WP_Error('bad_request','Missing JSON body', array('status'=>400));

    $title = (isset($data['date']) ? $data['date'].' '.$data['session'] : 'Pool Log'). ' - '. (wp_get_current_user()->user_login);
    $post_id = wp_insert_post(array(
      'post_type' => 'oceanides_pool_log',
      'post_status' => 'publish',
      'post_title' => sanitize_text_field($title),
      'post_author' => get_current_user_id()
    ));
    if (is_wp_error($post_id)) return $post_id;

    $fields = array('date','session','location','ph','dpd1','dpd3','cc','waterTemp','airTemp','weather','cya','tasks');
    foreach ($fields as $f){
      if (isset($data[$f])){
        if ($f === 'tasks' && is_array($data[$f])){
          update_post_meta($post_id, $f, array_map('sanitize_text_field', $data[$f]));
        } else {
          update_post_meta($post_id, $f, sanitize_text_field($data[$f]));
        }
      }
    }
    return array('id'=>$post_id, 'status'=>'ok');
  }

  public function get_logs($req){
    $limit = max(1, min(500, intval($req->get_param('limit') ?: 100)));
    $q = new WP_Query(array('post_type'=>'oceanides_pool_log','posts_per_page'=>$limit,'orderby'=>'date','order'=>'DESC'));
    $out = array();
    while($q->have_posts()){ $q->the_post();
      $meta = get_post_meta(get_the_ID());
      $get = function($k) use ($meta){ return isset($meta[$k][0]) ? maybe_unserialize($meta[$k][0]) : ''; };
      $out[] = array(
        'id'=>get_the_ID(),
        'date'=>$get('date'),
        'session'=>$get('session'),
        'location'=>$get('location'),
        'ph'=>$get('ph'),
        'dpd1'=>$get('dpd1'),
        'dpd3'=>$get('dpd3'),
        'cc'=>$get('cc'),
        'waterTemp'=>$get('waterTemp'),
        'airTemp'=>$get('airTemp'),
        'weather'=>$get('weather'),
        'cya'=>$get('cya'),
        'tasks'=>$get('tasks'),
        'author'=>get_the_author(),
        'created'=>get_the_date('c')
      );
    }
    wp_reset_postdata();
    return $out;
  }

  public function delete_log($req){
    $id = intval($req['id']);
    if (get_post_type($id) !== 'oceanides_pool_log') return new WP_Error('not_found','Not found', array('status'=>404));
    $res = wp_delete_post($id, true);
    if (!$res) return new WP_Error('delete_failed','Failed to delete', array('status'=>500));
    return array('deleted'=>true);
  }

  public function export_csv($req){
    if (!current_user_can('manage_options')) return new WP_Error('forbidden','Admins only', array('status'=>403));
    $q = new WP_Query(array('post_type'=>'oceanides_pool_log','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC'));
    $headers = array('date','session','location','ph','dpd1','dpd3','cc','waterTemp','airTemp','weather','cya','tasks','author','created');
    $rows = array();
    $rows[] = implode(',', $headers);
    while($q->have_posts()){ $q->the_post();
      $meta = get_post_meta(get_the_ID());
      $get = function($k) use ($meta){ return isset($meta[$k][0]) ? maybe_unserialize($meta[$k][0]) : ''; };
      $row = array(
        $get('date'), $get('session'), $get('location'),
        $get('ph'), $get('dpd1'), $get('dpd3'), $get('cc'),
        $get('waterTemp'), $get('airTemp'), $get('weather'),
        $get('cya'),
        is_array($get('tasks')) ? implode(' | ', $get('tasks')) : $get('tasks'),
        get_the_author(),
        get_the_date('c')
      );
      $row = array_map(function($v){ $v = str_replace(',', ' ', (string)$v); return $v; }, $row);
      $rows[] = implode(',', $row);
    }
    wp_reset_postdata();
    $csv = implode("\n", $rows);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=oceanides-pool-logs.csv');
    echo $csv;
    exit;
  }
}
new Oceanides_Pool_REST();

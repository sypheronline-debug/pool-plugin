<?php
/**
 * Plugin Name: Oceanides Pool Log Pro
 * Plugin URI: https://oceanidespool.com/
 * Description: Log and manage your pool's chemical readings with ease.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com/
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: oceanides-pool-log-pro
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Define constants
 */
define( 'OPLP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require OPLP_PLUGIN_DIR . 'includes/class-oceanides-pool-log-pro.php';


/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_oceanides_pool_log_pro() {
    $plugin = new Oceanides_Pool_Log_Pro();
    $plugin->run();
}

// Load plugin textdomain for translations - MOVED THIS HIGHER
add_action( 'plugins_loaded', function() {
    load_plugin_textdomain( 'oceanides-pool-log-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
});

// Add the database table creation hook
register_activation_hook( __FILE__, [ 'Oceanides_Admin', 'install' ] );


// RUN THE PLUGIN
run_oceanides_pool_log_pro();
<?php
/**
 * Plugin Name: Oceanides Pool Log Pro
 * Plugin URI: https://oceanidespool.com/
 * Description: Log and manage your pool's chemical readings with ease.
 * Version: 1.1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com/
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: oceanides-pool-log-pro
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Define constants
 */
define( 'OPLP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require OPLP_PLUGIN_DIR . 'includes/class-oceanides-pool-log-pro.php';

// === NEW & CORRECTED HOOKS ===

// 1. Load the text domain for translations as soon as plugins are loaded.
add_action( 'plugins_loaded', function() {
    load_plugin_textdomain( 'oceanides-pool-log-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
});

// 2. Register the activation hook to create the database table.
//    This tells WordPress to call the 'install' function inside the 'Oceanides_Admin' class upon activation.
register_activation_hook( __FILE__, [ 'Oceanides_Admin', 'install' ] );


/**
 * Begins execution of the plugin.
 *
 * @since    1.0.0
 */
function run_oceanides_pool_log_pro() {
    $plugin = new Oceanides_Pool_Log_Pro();
    $plugin->run();
}

// Run the plugin.
run_oceanides_pool_log_pro();
<?php

class Oceanides_Rest {

    // ... (other class methods)

    /**
     * Endpoint to get all records.
     * FIND a method like this in your file.
     */
    public function get_records( $request ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pool_water_records';
        
        $results = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY reading_date DESC" );
        
        return new WP_REST_Response( $results, 200 );
    }

    /**
     * Endpoint to save a new record.
     * FIND a method like this in your file and replace its contents.
     */
    public function save_record( $request ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pool_water_records';
        
        // Get data from the request
        $params = $request->get_json_params();

        // Sanitize data
        $data = [
            'reading_date'     => sanitize_text_field( $params['reading_date'] ),
            'ph_level'         => floatval( $params['ph_level'] ),
            'chlorine_level'   => floatval( $params['chlorine_level'] ),
            'alkalinity'       => intval( $params['alkalinity'] ),
            'calcium_hardness' => intval( $params['calcium_hardness'] ),
            'notes'            => sanitize_textarea_field( $params['notes'] ),
            'created_at'       => current_time( 'mysql' ),
        ];

        $result = $wpdb->insert( $table_name, $data );

        if ( $result ) {
            return new WP_REST_Response( [ 'success' => true, 'message' => 'Record saved.' ], 200 );
        } else {
            return new WP_REST_Response( [ 'success' => false, 'message' => 'Failed to save record.' ], 500 );
        }
    }

    // ... (other class methods, like the one that registers the REST routes)
}
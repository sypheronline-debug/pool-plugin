<?php

class Oceanides_Admin {

    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
    }

    /**
     * Creates the custom database table when the plugin is activated.
     * This function is called by the register_activation_hook in the main plugin file.
     */
    public static function install() {
        global $wpdb;
        // This table name MUST match the one used in class-oceanides-rest.php
        $table_name = $wpdb->prefix . 'oceanides_pool_logs'; 
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            reading_date date NOT NULL,
            ph_level decimal(4,2) NOT NULL,
            chlorine_level decimal(4,2) NOT NULL,
            alkalinity int(11) NOT NULL,
            calcium_hardness int(11) DEFAULT 0 NOT NULL,
            notes text,
            created_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
    }

    /**
     * Adds the admin menu item.
     */
    public function admin_menu() {
        add_menu_page(
            __('Oceanides Pool Log', 'oceanides-pool-log-pro'), // Translatable Page Title
            'Oceanides', // Menu Title
            'manage_options',
            'oceanides-pool-log-pro',
            array($this, 'admin_page'), // Function to render the page
            'dashicons-chart-area',
            20
        );
    }

    /**
     * Renders the single admin page for the plugin.
     * This is the updated, single version of this function.
     */
    public function admin_page() {
        // --- Language Switching Logic ---
        $current_lang = isset( $_GET['lang'] ) && $_GET['lang'] === 'fr' ? 'fr_FR' : 'en_US';
        $is_french = ($current_lang === 'fr_FR');
        ?>
        <div class="wrap">
            <div id="oceanides-app">
                <div class="language-switcher" style="text-align: right; padding: 15px; border: 1px solid #ccc; background: #fff; margin-bottom: 20px;">
                    <a href="?page=oceanides-pool-log-pro&lang=en" style="<?php echo !$is_french ? 'font-weight:bold; text-decoration: none;' : 'text-decoration: none;'; ?>">English</a> |
                    <a href="?page=oceanides-pool-log-pro&lang=fr" style="<?php echo $is_french ? 'font-weight:bold; text-decoration: none;' : 'text-decoration: none;'; ?>">Français</a>
                </div>
                <!-- Your JavaScript app will take over from here -->
            </div>
        </div>
        <?php
        
        // Pass all our translated strings from PHP to the JavaScript App.
        wp_localize_script('oceanides-app-js', 'oceanides_i18n', [
            'mainTitle'         => __('Pool Water Quality Records', 'oceanides-pool-log-pro'),
            'newReadingTitle'   => __('Enter New Water Readings', 'oceanides-pool-log-pro'),
            'savedRecordsTitle' => __('Saved Records', 'oceanides-pool-log-pro'),
            'dateLabel'         => __('Date', 'oceanides-pool-log-pro'),
            'phLabel'           => __('pH Level', 'oceanides-pool-log-pro'),
            'chlorineLabel'     => __('Chlorine Level (ppm)', 'oceanides-pool-log-pro'),
            'alkalinityLabel'   => __('Total Alkalinity (ppm)', 'oceanides-pool-log-pro'),
            'hardnessLabel'     => __('Calcium Hardness (ppm)', 'oceanides-pool-log-pro'),
            'notesLabel'        => __('Notes', 'oceanides-pool-log-pro'),
            'notesPlaceholder'  => __('Any observations...', 'oceanides-pool-log-pro'),
            'saveButton'        => __('Save Record', 'oceanides-pool-log-pro'),
            'noRecords'         => __('No records found.', 'oceanides-pool-log-pro'),
        ]);
    }
}

new Oceanides_Admin();
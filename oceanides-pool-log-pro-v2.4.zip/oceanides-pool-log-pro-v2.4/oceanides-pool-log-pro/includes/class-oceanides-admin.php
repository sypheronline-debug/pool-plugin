<?php
if (!defined('ABSPATH')) exit;

class Oceanides_Pool_Admin {
  public function __construct(){
    add_action('admin_menu', array($this, 'menu'));
    add_action('admin_init', array($this, 'settings'));
  }

  public function menu(){
    add_menu_page('Océanides Pool Log','Pool Log','manage_options','oceanides-pool-log', array($this,'render_logs_page'), 'dashicons-water', 26);
    add_submenu_page('oceanides-pool-log','Settings','Settings','manage_options','oceanides-pool-log-settings', array($this,'render_settings_page'));
    add_submenu_page('oceanides-pool-log','Export CSV','Export CSV','manage_options','oceanides-pool-log-export', array($this,'render_export_page'));
  }

  public function settings(){
    register_setting('oceanides_pool_log_settings_group','oceanides_pool_log_settings');
    add_settings_section('oceanides_pool_log_main','Header & Branding', '__return_false', 'oceanides_pool_log_settings');

    add_settings_field('header_title','Header title', array($this,'field_header_title'),'oceanides_pool_log_settings','oceanides_pool_log_main');
    add_settings_field('header_subtitle','Subtitle', array($this,'field_header_subtitle'),'oceanides_pool_log_settings','oceanides_pool_log_main');
    add_settings_field('logo_url','Logo URL', array($this,'field_logo_url'),'oceanides_pool_log_settings','oceanides_pool_log_main');

    add_settings_section('oceanides_pool_log_tasks','Tasks (one per line)', '__return_false', 'oceanides_pool_log_settings');
    add_settings_field('tasks_daily','Daily', array($this,'field_tasks_daily'),'oceanides_pool_log_settings','oceanides_pool_log_tasks');
    add_settings_field('tasks_twice_weekly','Twice Weekly', array($this,'field_tasks_twice_weekly'),'oceanides_pool_log_settings','oceanides_pool_log_tasks');
    add_settings_field('tasks_weekly','Weekly', array($this,'field_tasks_weekly'),'oceanides_pool_log_settings','oceanides_pool_log_tasks');
  }

  private function get_opts(){ return oceanides_pool_log_get_settings(); }

  public function field_header_title(){
    $opts = $this->get_opts();
    echo '<input type="text" name="oceanides_pool_log_settings[header_title]" value="'.esc_attr($opts['header_title']).'" class="regular-text" />';
  }
  public function field_header_subtitle(){
    $opts = $this->get_opts();
    echo '<input type="text" name="oceanides_pool_log_settings[header_subtitle]" value="'.esc_attr($opts['header_subtitle']).'" class="regular-text" />';
  }
  public function field_logo_url(){
    $opts = $this->get_opts();
    echo '<input type="text" name="oceanides_pool_log_settings[logo_url]" value="'.esc_attr($opts['logo_url']).'" class="regular-text" />';
  }

  public function field_tasks_daily(){
    $opts = $this->get_opts();
    echo '<textarea name="oceanides_pool_log_settings[tasks][daily]" rows="6" class="large-text">'.esc_textarea(implode("\n",$opts['tasks']['daily'])).'</textarea>';
  }
  public function field_tasks_twice_weekly(){
    $opts = $this->get_opts();
    echo '<textarea name="oceanides_pool_log_settings[tasks][twice_weekly]" rows="4" class="large-text">'.esc_textarea(implode("\n",$opts['tasks']['twice_weekly'])).'</textarea>';
  }
  public function field_tasks_weekly(){
    $opts = $this->get_opts();
    echo '<textarea name="oceanides_pool_log_settings[tasks][weekly]" rows="6" class="large-text">'.esc_textarea(implode("\n",$opts['tasks']['weekly'])).'</textarea>';
  }

  public function render_settings_page(){
    echo '<div class="wrap"><h1>Océanides Pool Log – Settings</h1>';
    echo '<form method="post" action="options.php">';
    settings_fields('oceanides_pool_log_settings_group');
    do_settings_sections('oceanides_pool_log_settings');
    submit_button();
    echo '</form></div>';
  }

  public function render_logs_page(){
    echo '<div class="wrap"><h1>Pool Logs</h1>';
    echo '<p>View recent entries below. Use Export for CSV of all entries.</p>';
    $args = array('post_type'=>'oceanides_pool_log','posts_per_page'=>50,'orderby'=>'date','order'=>'DESC');
    $q = new WP_Query($args);
    echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Session</th><th>pH</th><th>DPD1</th><th>DPD3</th><th>CC</th><th>CYA</th><th>Water °C</th><th>Air °C</th><th>Weather</th><th>Location</th><th>Tasks</th><th>Author</th></tr></thead><tbody>';
    while($q->have_posts()){ $q->the_post();
      $meta = get_post_meta(get_the_ID());
      $get = function($k) use ($meta){ return isset($meta[$k][0]) ? maybe_unserialize($meta[$k][0]) : ''; };
      echo '<tr>';
      echo '<td>'.esc_html($get('date')).'</td>';
      echo '<td>'.esc_html($get('session')).'</td>';
      echo '<td>'.esc_html($get('ph')).'</td>';
      echo '<td>'.esc_html($get('dpd1')).'</td>';
      echo '<td>'.esc_html($get('dpd3')).'</td>';
      echo '<td>'.esc_html($get('cc')).'</td>';
      echo '<td>'.esc_html($get('cya')).'</td>';
      echo '<td>'.esc_html($get('waterTemp')).'</td>';
      echo '<td>'.esc_html($get('airTemp')).'</td>';
      echo '<td>'.esc_html($get('weather')).'</td>';
      echo '<td>'.esc_html($get('location')).'</td>';
      echo '<td>'.esc_html(implode(" • ", (array)$get('tasks'))).'</td>';
      $u = get_user_by('id', get_post_field('post_author', get_the_ID()));
      echo '<td>'.esc_html($u ? $u->user_login : '').'</td>';
      echo '</tr>';
    }
    wp_reset_postdata();
    echo '</tbody></table></div>';
  }

  public function render_export_page(){
    $url = rest_url('oceanides/v1/logs/export');
    echo '<div class="wrap"><h1>Export CSV</h1>';
    echo '<p><a class="button button-primary" href="'.esc_url($url).'">Download CSV of all logs</a></p>';
    echo '</div>';
  }
}
new Oceanides_Pool_Admin();

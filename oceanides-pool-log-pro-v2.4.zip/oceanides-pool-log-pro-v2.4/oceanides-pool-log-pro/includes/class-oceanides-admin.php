<?php

class Oceanides_Admin {

    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
    }

    /**
     * Activation hook. Creates the database table.
     * This is a new, required function.
     */
    public static function install() {
        global $wpdb;
        // NOTE: Changed table name to match what the REST class uses
        $table_name = $wpdb->prefix . 'oceanides_pool_logs'; 
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            reading_date date NOT NULL,
            ph_level decimal(4,2) NOT NULL,
            chlorine_level decimal(4,2) NOT NULL,
            alkalinity int(11) NOT NULL,
            calcium_hardness int(11) DEFAULT 0 NOT NULL,
            notes text,
            created_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
    }

    public function admin_menu() {
        add_menu_page(
            // Use translation function __() for page title
            __('Oceanides Pool Log', 'oceanides-pool-log-pro'), 
            'Oceanides',
            'manage_options',
            'oceanides-pool-log-pro',
            array($this, 'admin_page'),
            'dashicons-chart-area',
            20
        );
    }

    public function admin_page() {
        // --- Language Switching Logic ---
        $current_lang = isset( $_GET['lang'] ) && $_GET['lang'] === 'fr' ? 'fr_FR' : 'en_US';
        $is_french = ($current_lang === 'fr_FR');
        
        // This is a simple way to switch. WordPress handles it if the textdomain is loaded.
        ?>
        <div class="wrap">
            <div id="oceanides-app">
                <div class="language-switcher" style="text-align: right; margin-bottom: 20px;">
                    <a href="?page=oceanides-pool-log-pro&lang=en" style="<?php echo !$is_french ? 'font-weight:bold;' : ''; ?>">English</a> |
                    <a href="?page=oceanides-pool-log-pro&lang=fr" style="<?php echo $is_french ? 'font-weight:bold;' : ''; ?>">Français</a>
                </div>
                <!-- The JavaScript app will render here, but we can pass translatable strings -->
            </div>
        </div>

        <?php
        // Pass translated strings to your JavaScript App
        wp_localize_script('oceanides-app-js', 'oceanides_i18n', [
            'mainTitle' => __('Pool Water Quality Records', 'oceanides-pool-log-pro'),
            'newReadingTitle' => __('Enter New Water Readings', 'oceanides-pool-log-pro'),
            'savedRecordsTitle' => __('Saved Records', 'oceanides-pool-log-pro'),
            'dateLabel' => __('Date', 'oceanides-pool-log-pro'),
            'phLabel' => __('pH Level', 'oceanides-pool-log-pro'),
            'chlorineLabel' => __('Chlorine Level (ppm)', 'oceanides-pool-log-pro'),
            'alkalinityLabel' => __('Total Alkalinity (ppm)', 'oceanides-pool-log-pro'),
            'hardnessLabel' => __('Calcium Hardness (ppm)', 'oceanides-pool-log-pro'),
            'notesLabel' => __('Notes', 'oceanides-pool-log-pro'),
            'notesPlaceholder' => __('Any observations...', 'oceanides-pool-log-pro'),
            'saveButton' => __('Save Record', 'oceanides-pool-log-pro'),
            'noRecords' => __('No records found.', 'oceanides-pool-log-pro'),
        ]);
    }
}

new Oceanides_Admin();